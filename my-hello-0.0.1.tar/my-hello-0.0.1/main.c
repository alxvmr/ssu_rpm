#include <glib.h>

gint
main (gint argc,
      gchar *argv)
{
    g_print ("Hello world!\n");

    return 0;
}